﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AplloMedApp.Startup))]
namespace AplloMedApp
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
