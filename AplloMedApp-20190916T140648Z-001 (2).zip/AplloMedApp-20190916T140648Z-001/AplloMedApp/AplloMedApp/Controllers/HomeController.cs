﻿using AplloMedApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AplloMedApp.Controllers
{
    public class HomeController : Controller
    {
        public static List<Medicine>medicineList = getMedicineDetails();
      
        public ActionResult Index()
        {
            return View(medicineList);
        }

        public ActionResult Envoice(string id)
        {
            var EnvoiceOfMedicine = medicineList.SingleOrDefault(m => m.MedicineName == id);
            return View(EnvoiceOfMedicine);
        }

        public ActionResult Delete(string id)
        {
            var index = medicineList.FindIndex(m => m.MedicineName == id);
            medicineList.RemoveAt(index);
            return RedirectToAction("Index");

        }
        [HttpGet]
        public ActionResult Add()
        {
            return View();

        }

        [HttpPost]
        public ActionResult Add(FormCollection collection)
        {
            var newMedicine = new Medicine();
            newMedicine.MedicineName = collection["MedicineName"];
            newMedicine.Price = Convert.ToDecimal(collection["Price"]);
            newMedicine.ExpiryDate = Convert.ToDateTime(collection["ExpiryDate"]);
            newMedicine.Status = collection["Status"];
            medicineList.Add(newMedicine);

            return RedirectToAction("Index");

        }

        public ActionResult Filtered(Medicine filteredList)
        {
            medicineList.Clear();
            medicineList.Add(filteredList);

            return RedirectToAction("Index");

        }
        public static List<Medicine> getMedicineDetails()
        {
            return new List<Medicine>
            {
                new Medicine {  MedicineName = "Medicine1", Price=100M, ExpiryDate = new DateTime(2019,1,18), Status= "Active" },
                new Medicine {  MedicineName = "Medicine2", Price=10M, ExpiryDate = new DateTime(2018,1,18), Status= "Expired" },
                new Medicine {  MedicineName = "Medicine3", Price=104M, ExpiryDate = new DateTime(2019,1,18), Status= "Active" },
                new Medicine {  MedicineName = "Medicine4", Price=10M, ExpiryDate = new DateTime(2018,5,10), Status= "About To Expire" },
                new Medicine {  MedicineName = "Medicine5", Price=1122M, ExpiryDate = new DateTime(2019,1,18), Status= "Active" }

            };
        }


    }
}