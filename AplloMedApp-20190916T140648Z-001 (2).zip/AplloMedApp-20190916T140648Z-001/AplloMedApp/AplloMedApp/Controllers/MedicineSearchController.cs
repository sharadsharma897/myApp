﻿using AplloMedApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace AplloMedApp.Controllers
{
    public class MedicineSearchController : ApiController
    {
        [HttpPost]
        public Medicine Post([FromBody]Medicine item)
        {
            var medList = HomeController.getMedicineDetails();
            var filteredList = medList.SingleOrDefault(m => m.MedicineName == item.MedicineName);
            return filteredList;
        }
    }
}